RPA 3-Way Invoice Matching - Regression Test Pack

Generated: 2026-09-12

PURPOSE
This pack uses NEW invoice references and new filenames so it can be run independently from the earlier INV-TEST-* pack.
It is designed against the current PO/GRN master data.

IMPORTANT PREPARATION
1. Do NOT add PO-RG-999 to PO_Data. It is the Missing PO test.
2. Keep GRN for PO-TEST-004 absent. It is the Missing GRN test.
3. For case 06 only, add INV-RG-106 to Existing_Invoices before sending the invoice. Use ERP_Duplicate_Seed.csv.
4. RPA_Live_Output should not already contain any INV-RG-* references before starting, except when the scenario explicitly tells you to keep the previous row.
5. Pending_File_Map does not need to be cleared when using the Process_ID-fixed Apps Script.

RECOMMENDED ORDER
01 Clean Match
02 Qty Mismatch
03 Price Mismatch
04 Missing GRN
05 Missing PO
06 ERP Duplicate
07 Calc Error
08 Approval Reject
09 Approval Approve
10 RPA Duplicate - send the SAME PDF twice
11 Same Ref / Supplier A
12 Same Ref / Supplier B - same ref as 11 intentionally
13 Process_ID Run A
14 Process_ID Run B - same filename as Run A intentionally

EXPECTED MASTER-DATA ASSUMPTIONS
PO-TEST-001: S-1001, qty 10, unit 1250, total 12500; GRN qty 10
PO-TEST-002: S-1002, qty 12, unit 500, total 6000; GRN qty 10
PO-TEST-003: S-1003, qty 5, unit 2000, total 10000; GRN qty 5
PO-TEST-004: S-1004, qty 20, unit 300, total 6000; NO GRN
PO-TEST-006: S-1006, qty 3, unit 3000, total 9000; GRN qty 3
PO-TEST-007: S-1007, qty 4, unit 1500, total 6000; GRN qty 4
PO-TEST-008: S-1008, qty 6, unit 1750, total 10500; GRN qty 6

SPECIAL NOTE ABOUT CASE 12
Cases 11 and 12 intentionally share invoice reference INV-RG-SHARED-111 but use different Supplier_Number values. This validates that the RPA duplicate rule does not incorrectly mark a different supplier as a duplicate. Case 12 should continue into normal matching and become Qty Mismatch because PO-TEST-002 has GRN qty 10 vs invoice/PO qty 12.

SPECIAL PROCESS_ID REGRESSION
Run_A and Run_B both use the physical filename Repeated_Name_Invoice.pdf but contain different invoice references. Run A must be completed/approved first. Then send Run B. The Apps Script must resolve the current pending file using the new Process_ID and must NOT reuse Run A's old Drive mapping.

OCR/DATA QUALITY
The current flow records OCR confidence as N/A when using the OpenAI text-extraction path, so this pack does not fake an OCR <85% test.
